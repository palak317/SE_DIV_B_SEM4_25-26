
import os
import random
import json
from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from datetime import datetime

app = Flask(__name__)
app.secret_key = "neary_mumbai_2024_secure"
CORS(app)

# --- MySQL Configuration ---
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+mysqlconnector://root:31072006Palak@localhost/local_helper_db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = 'static/uploads'

db = SQLAlchemy(app)

# --- Regional Coordinate Mapping ---
REGION_COORDS = {
    "thane": (19.2183, 72.9781), "bandra": (19.0596, 72.8295),
    "andheri": (19.1136, 72.8697), "dadar": (19.0178, 72.8478),
    "powai": (19.1176, 72.9060), "colaba": (18.9067, 72.8147),
    "juhu": (19.1000, 72.8267), "worli": (19.0100, 72.8150),
    "borivali": (19.2307, 72.8567), "vashi": (19.0330, 73.0297),
    "mumbai": (19.0760, 72.8777)
}


# --- Database Models ---

class Admin(db.Model):
    __tablename__ = 'admins'
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(100), nullable=False)
    access_level = db.Column(db.String(20), default='super_admin')


class Booking(db.Model):
    __tablename__ = 'bookings'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    provider_id = db.Column(db.Integer, db.ForeignKey('service_providers.id'), nullable=True)
    service_type = db.Column(db.String(50), nullable=False)
    booking_date = db.Column(db.Date, nullable=False)
    booking_time = db.Column(db.Time, nullable=False)
    hours = db.Column(db.Integer, nullable=False)
    people = db.Column(db.Integer, nullable=False)
    total_price = db.Column(db.Float, nullable=False)
    payment_method = db.Column(db.String(20), default='COD')
    status = db.Column(db.String(20), default='pending')
    otp_start = db.Column(db.String(4))
    otp_end = db.Column(db.String(4))
    start_time = db.Column(db.DateTime)
    messages = db.Column(db.Text, default='[]')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Provider(db.Model):
    __tablename__ = 'service_providers'
    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(100), nullable=False)
    middle_name = db.Column(db.String(100))
    last_name = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(20), unique=True, nullable=False)
    gmail = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(100), nullable=False, default='pass123')
    address = db.Column(db.Text)
    interests = db.Column(db.Text)
    photo_path = db.Column(db.String(255))
    aadhaar_path = db.Column(db.String(255))
    type = db.Column(db.String(50), default='guide')
    lat = db.Column(db.Float)
    lng = db.Column(db.Float)
    status = db.Column(db.String(20), default='pending')


class User(db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    age = db.Column(db.Integer)
    phone = db.Column(db.String(20), unique=True)
    email = db.Column(db.String(100), unique=True, nullable=False)
    location = db.Column(db.String(255))
    password = db.Column(db.String(100), nullable=False)


# --- Initialize DB ---
with app.app_context():
    db.create_all()


# --- WEB ROUTES ---

@app.route('/')
def gateway():
    return render_template('neary_gateway.html')


@app.route('/user_portal')
def user_portal():
    return render_template('index.html') if session.get('role') == 'user' else redirect(url_for('gateway'))


@app.route('/provider_portal')
def provider_portal():
    return render_template('provider.html') if session.get('role') == 'provider' else redirect(url_for('gateway'))


@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('gateway'))


# --- AUTH API ---

@app.route('/api/auth/login', methods=['POST'])
def login():
    data = request.json
    email = data.get('email')
    password = data.get('password')

    admin = Admin.query.filter_by(email=email, password=password).first()
    if admin:
        session.update({'user_id': admin.id, 'role': 'admin', 'email': email})
        return jsonify({"status": "success", "redirect": "/admin_dashboard"})

    provider = Provider.query.filter_by(gmail=email, password=password).first()
    if provider:
        session.update({'user_id': provider.id, 'role': 'provider', 'user_name': provider.first_name, 'email': email})
        return jsonify({"status": "success", "redirect": "/provider_portal"})

    user = User.query.filter_by(email=email, password=password).first()
    if user:
        session.update({'user_id': user.id, 'role': 'user', 'user_name': user.name, 'email': email})
        return jsonify({"status": "success", "redirect": "/user_portal"})

    return jsonify({"status": "error", "message": "Invalid Credentials"}), 401


# --- UNIFIED PROFILE LOGIC ---

@app.route('/api/provider/profile', methods=['GET'])
def get_profile_data_serviceprovider():
    email = session.get('email')
    if not email: return jsonify({"status": "error"}), 401

    # Search both tables as requested
    p = Provider.query.filter_by(gmail=email).first()
    u = User.query.filter_by(email=email).first()

    if p:
        interests = json.loads(p.interests) if p.interests else []
        return jsonify({
            "status": "success",
            "provider": {
                "id": p.id, "name": f"{p.first_name} {p.last_name}",
                "email": p.gmail, "interests": interests, "status": p.status
            }
        })
    elif u:
        return jsonify({
            "status": "success",
            "provider": {"id": u.id, "name": u.name, "email": u.email, "status": "User Account"}
        })
    return jsonify({"status": "error"}), 404


@app.route('/api/user/profile', methods=['GET'])
def get_user_profile():
    email = session.get('email')
    if not email: return jsonify({"status": "error"}), 401

    # Search both tables as requested
    u = User.query.filter_by(email=email).first()
    p = Provider.query.filter_by(gmail=email).first()

    if u:
        return jsonify({
            "status": "success",
            "user": {"name": u.name, "email": u.email, "location": u.location or "Mumbai Grid"}
        })
    elif p:
        return jsonify({
            "status": "success",
            "user": {"name": f"{p.first_name} {p.last_name}", "email": p.gmail,
                     "location": p.address or "Provider Grid"}
        })
    return jsonify({"status": "error"}), 404


# --- USER API ---

@app.route('/api/user/book', methods=['POST'])
def create_booking():
    if session.get('role') != 'user':
        return jsonify({"status": "error", "message": "Unauthorized"}), 401
    data = request.json
    try:
        new_booking = Booking(
            user_id=session['user_id'],
            service_type=data['service_type'],
            booking_date=datetime.strptime(data['date'], '%Y-%m-%d').date(),
            booking_time=datetime.strptime(data['time'], '%H:%M').time(),
            hours=int(data['hours']),
            people=int(data['people']),
            total_price=float(data['price']),
            payment_method=data.get('payment', 'COD'),
            status='pending'
        )
        db.session.add(new_booking)
        db.session.commit()
        return jsonify({"status": "success", "message": "Booked"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500


@app.route('/api/user/history', methods=['GET'])
def get_user_history():
    u_id = session.get('user_id')
    # Fetch all bookings for this user to show in "Past Bookings"
    history = Booking.query.filter_by(user_id=u_id).order_by(Booking.created_at.desc()).all()
    return jsonify([{
        "id": b.id, "service": b.service_type, "date": b.booking_date.strftime('%Y-%m-%d'),
        "total": b.total_price, "status": b.status
    } for b in history])


@app.route('/api/user/active_bookings', methods=['GET'])
def get_user_active_bookings():
    u_id = session.get('user_id')
    active_statuses = ['accepted', 'on_the_way', 'arrived', 'in_progress']
    active = Booking.query.filter(Booking.user_id == u_id, Booking.status.in_(active_statuses)).all()
    results = []
    for b in active:
        p = Provider.query.get(b.provider_id)
        current_otp = b.otp_end if b.status == 'in_progress' else b.otp_start
        results.append({
            "id": b.id, "status": b.status, "service": b.service_type,
            "otp": current_otp, "hours": b.hours,
            "start_time": b.start_time.isoformat() if b.start_time else None,
            "provider_name": f"{p.first_name} {p.last_name}" if p else "Assigned Node"
        })
    return jsonify(results)


# --- PROVIDER API ---

@app.route('/api/provider/upcoming', methods=['GET'])
def get_provider_bookings():
    p_id = session.get('user_id')
    p = Provider.query.get(p_id)
    interests = json.loads(p.interests) if p.interests else []

    jobs = Booking.query.filter(
        db.or_(
            db.and_(Booking.status == 'pending', Booking.service_type.in_(interests)),
            db.and_(Booking.provider_id == p_id, Booking.status != 'completed')
        )
    ).all()

    return jsonify([{
        "id": b.id, "user_name": User.query.get(b.user_id).name if User.query.get(b.user_id) else "Anonymous",
        "service": b.service_type, "date": b.booking_date.strftime('%Y-%m-%d'),
        "time": b.booking_time.strftime('%H:%M'), "total": b.total_price,
        "status": b.status, "hours": b.hours,
        "start_time": b.start_time.isoformat() if b.start_time else None
    } for b in jobs])


@app.route('/api/provider/booking_action', methods=['POST'])
def provider_action():
    data = request.json
    booking = Booking.query.get(data.get('booking_id'))
    if data.get('action') == 'accept':
        booking.status = 'accepted'
        booking.provider_id = session.get('user_id')
        booking.otp_start = str(random.randint(1000, 9999))
        booking.otp_end = str(random.randint(1000, 9999))
        db.session.commit()
        return jsonify({"status": "success"})
    return jsonify({"status": "error"}), 400


@app.route('/api/provider/update_interests', methods=['POST'])
def update_provider_interests():
    p_id = session.get('user_id')
    provider = Provider.query.get(p_id)
    if provider:
        provider.interests = json.dumps(request.json.get('interests', []))
        db.session.commit()
        return jsonify({"status": "success"})
    return jsonify({"status": "error"}), 404


# --- MISSION TELEMETRY & CHAT ---

@app.route('/api/mission/update_status', methods=['POST'])
def update_mission_status():
    booking = Booking.query.get(request.json.get('booking_id'))
    if booking:
        booking.status = request.json.get('status')
        db.session.commit()
        return jsonify({"status": "success"})
    return jsonify({"status": "error"}), 404


@app.route('/api/mission/verify_otp', methods=['POST'])
def verify_mission_otp():
    data = request.json
    booking = Booking.query.get(data.get('booking_id'))
    otp_type, otp = data.get('type'), data.get('otp')

    if otp_type == 'start' and booking.otp_start == otp:
        booking.status, booking.start_time = 'in_progress', datetime.now()
        db.session.commit()
        return jsonify({"status": "success"})
    elif otp_type == 'end' and booking.otp_end == otp:
        booking.status = 'completed'
        db.session.commit()
        return jsonify({"status": "success"})
    return jsonify({"status": "error", "message": "Invalid OTP"}), 401


@app.route('/api/mission/chat', methods=['GET', 'POST'])
def handle_mission_chat():
    b_id = request.args.get('booking_id') if request.method == 'GET' else request.json.get('booking_id')
    booking = Booking.query.get(b_id)
    if not booking: return jsonify([]), 404
    if request.method == 'POST':
        history = json.loads(booking.messages or '[]')
        history.append({
            "sender": session.get('role'), "text": request.json.get('text'),
            "time": datetime.now().strftime('%H:%M')
        })
        booking.messages = json.dumps(history)
        db.session.commit()
        return jsonify({"status": "success"})
    return jsonify(json.loads(booking.messages or '[]'))


# --- ADMIN COMMAND CENTER ROUTES ---

@app.route('/admin_dashboard')
def admin_dashboard():
    """Renders the Tactical Admin Dashboard for authorized personnel."""
    if session.get('role') == 'admin':
        return render_template('admin.html')
    return redirect(url_for('gateway'))


@app.route('/api/admin/stats', methods=['GET'])
def get_admin_stats():
    """Provides live telemetry counts for the dashboard tiles."""
    if session.get('role') != 'admin': return jsonify({"error": "Unauthorized"}), 401

    pending = Provider.query.filter_by(status='pending').count()
    approved = Provider.query.filter_by(status='approved').count()
    rejected = Provider.query.filter_by(status='rejected').count()
    total = Provider.query.count()

    return jsonify({
        "pending": pending,
        "approved": approved,
        "rejected": rejected,
        "total": total
    })


@app.route('/api/admin/providers', methods=['GET'])
def get_admin_providers():
    """Returns a list of providers filtered by their verification status."""
    if session.get('role') != 'admin': return jsonify([]), 401

    status_filter = request.args.get('status', 'pending')
    nodes = Provider.query.filter_by(status=status_filter).all()

    results = []
    for n in nodes:
        # Safely handle interests JSON
        try:
            interests_list = json.loads(n.interests) if n.interests else []
        except:
            interests_list = [n.interests] if n.interests else []

        results.append({
            "id": n.id,
            "name": f"{n.first_name} {n.last_name}",
            "phone": n.phone,
            "email": n.gmail,
            "status": n.status,
            "interests": interests_list,
            "photo": f"/static/uploads/{n.photo_path}" if n.photo_path else "",
            "aadhaar": f"/static/uploads/{n.aadhaar_path}" if n.aadhaar_path else ""
        })
    return jsonify(results)


@app.route('/api/admin/update_provider', methods=['POST'])
def admin_update_provider():
    """Enables Admin to authorize (approve) or void (reject) specialist nodes."""
    if session.get('role') != 'admin': return jsonify({"status": "error"}), 401

    data = request.json
    provider_id = data.get('id')
    new_status = data.get('status')  # 'approved' or 'rejected'

    provider = Provider.query.get(provider_id)
    if provider:
        provider.status = new_status
        db.session.commit()
        return jsonify({"status": "success"})

    return jsonify({"status": "error", "message": "Node not found"}), 404
if __name__ == '__main__':
    app.run(debug=True, port=5000, threaded=True)
